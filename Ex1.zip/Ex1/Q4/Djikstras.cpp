#include <iostream>
#include <limits.h>
#include <vector>

using namespace std;

int minDistance(vector<int>& dist, vector<bool>& sptSet) {
    int min = INT_MAX, min_index;

    for (size_t v = 0; v < dist.size(); v++) {
        if (!sptSet[v] && dist[v] <= min) {
            min = dist[v];
            min_index = v;
        }
    }

    return min_index;
}

void printSolution(vector<int>& dist) {
    cout << "Vertex \t Distance from Source" << endl;
    for (size_t i = 0; i < dist.size(); i++) {
        cout << i << " \t\t\t\t" << dist[i] << endl;
    }
}

void dijkstra(vector<vector<int>>& graph, int src, int V) {
    vector<int> dist(V, INT_MAX);
    vector<bool> sptSet(V, false);

    dist[src] = 0;

    for (int count = 0; count < V - 1; count++) {
        int u = minDistance(dist, sptSet);
        sptSet[u] = true;

        for (int v = 0; v < V; v++) {
            if (!sptSet[v] && graph[u][v] && dist[u] != INT_MAX && dist[u] + graph[u][v] < dist[v]) {
                dist[v] = dist[u] + graph[u][v];
            }
        }
    }

    printSolution(dist);
}

int main() {
    int option;
    vector<vector<int>> graph;
    int V = 0;

    while (true) {
        cout << "Options:\n1. Create new graph\n2. Modify existing graph\n3. Find shortest path\n4. Exit\nChoose an option: ";
        cin >> option;

        if (option == 1) {
            cout << "Enter the number of vertices in the graph: ";
            cin >> V;

            graph.assign(V, vector<int>(V, 0));

            cout << "Enter the weight of the edges in the adjacency matrix (enter 0 for no edge):\n";
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    cout << "Edge weight from vertex " << i << " to vertex " << j << ": ";
                    cin >> graph[i][j];
                    if (graph[i][j] < 0) {
                        cout << "Invalid input. Please enter a non-negative weight or -1 for no edge." << endl;
                        j--; // Repeat the input for this edge
                    }
                }
            }
        } else if (option == 2) {
            if (graph.empty()) {
                cout << "Graph not yet created. Please create a new graph first." << endl;
                continue;
            }

            int u, v, weight;
            cout << "Enter the source vertex:" << endl;
            cin >> u;
            cout << "Enter the destination vertex:" << endl;
            cin >> v;
            cout << "Enter the new weight of the edge:" << endl;
            cin >> weight;

            if (u < 0 || u >= V || v < 0 || v >= V || weight < 0) {
                cout << "Invalid input. Please enter valid values." << endl;
                continue;
            }

            graph[u][v] = weight;
            graph[v][u] = weight;
        } else if (option == 3) {
            if (graph.empty()) {
                cout << "Graph not yet created. Please create a new graph first." << endl;
                continue;
            }

            int src;
            cout << "Enter the source vertex for shortest path calculation: ";
            cin >> src;

            if (src < 0 || src >= V) {
                cout << "Invalid source vertex. Please enter a valid vertex." << endl;
                continue;
            }

            dijkstra(graph, src, V);
        } else if (option == 4) {
            break;
        } else {
            cout << "Invalid option. Please choose a valid option." << endl;
        }
    }

    return 0;
}
